package org.maxim.crud.repository;

import org.maxim.crud.model.Specialty;

public interface SpecialtyRepository extends GenericRepository<Specialty, Long>{
}
