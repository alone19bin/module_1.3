package org.maxim.crud;

public class Main {
    public static void main(String[] args) {
        StartProgram crud = new StartProgram();
        crud.start();
    }
}
