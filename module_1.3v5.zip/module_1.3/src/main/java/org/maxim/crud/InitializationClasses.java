package org.maxim.crud;

import org.maxim.crud.controller.DeveloperController;
import org.maxim.crud.controller.SkillController;
import org.maxim.crud.repository.DeveloperRepository;
import org.maxim.crud.repository.gson.GsonDeveloperRepositoryImpl;
import org.maxim.crud.repository.gson.GsonSkillRepositoryImpl;
import org.maxim.crud.view.DeveloperView;

public class InitializationClasses {
    public void developerRun() {
        DeveloperRepository developerRepository = new GsonDeveloperRepositoryImpl();
        DeveloperController developerController = new DeveloperController(developerRepository);
        SkillController skillController = new SkillController(new GsonSkillRepositoryImpl());
        DeveloperView DeveloperView = new DeveloperView(developerController, skillController);
        DeveloperView.start();
    }
}
