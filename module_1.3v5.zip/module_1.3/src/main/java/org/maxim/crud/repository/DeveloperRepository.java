package org.maxim.crud.repository;

import org.maxim.crud.model.Developer;

public interface DeveloperRepository extends GenericRepository<Developer, Long>{

}
