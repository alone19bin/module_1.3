package org.maxim.crud.repository;

import org.maxim.crud.model.Skill;

public interface SkillRepository extends GenericRepository<Skill, Long> {
}
