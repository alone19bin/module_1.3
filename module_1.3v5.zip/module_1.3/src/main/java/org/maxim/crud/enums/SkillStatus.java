package org.maxim.crud.enums;

public enum SkillStatus {
    ACTIVE, DELETED
}
