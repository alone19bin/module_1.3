package org.maxim.crud.enums;

public enum SpecialtyStatus {
    ACTIVE, DELETED
}
